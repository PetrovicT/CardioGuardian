
<!DOCTYPE html>
<html>
    <head>	
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="<?php echo base_url(); ?>/photos/cardioguardian.png" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/w3.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/stil.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/pitanja.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/profil.css">
        <style>h1,h2,h3,h4,h5,h6 {font-family: "Oswald"} body {font-family: "Open Sans"}</style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
        <script src = "<?php echo base_url(); ?>/js/profil.js"></script>
        <script src = "<?php echo base_url(); ?>/js/script.js"></script>
        <title>Pregled profila</title>
    </head>

    <body class="w3-light-grey">

        <!-- Header -->
        <?php
        require 'resources/header.php';
        ?>

        <?php
        // dohvatanje kontrolera i userId
        $controller = session()->get("controller");
        $userId = $idKorisnikaCijiProfilGledamo;

        // korisnik model nam treba radi dohvatanja podataka o korisniku ciji profil gledamo
        use App\Models\KorisnikModel;
        use App\Models\PolModel;
        use App\Models\GradModel;
        use App\Models\TipKorisnikaModel;
        ?>
        <div>
            <!-- Profil-->
            <?php
            $korisnikModel = new KorisnikModel();
            $korisnik = $korisnikModel->find("$userId");
            // dohvatanje grada
            if ($korisnik->grad_idGrad == null)
                $nazivGrada = "Nije uneto";
            else {
                $gradModel = new GradModel();
                $nazivGrada = $gradModel->nadjiNazivGrada($korisnik->grad_idGrad);
            }
            // dohvatanje pola
            if ($korisnik->pol_idPol == null)
                $pol = "Nije uneto";
            else {
                $polModel = new PolModel();
                $pol = $polModel->nadjiPol($korisnik->pol_idPol);
            }
            // dohvatanje username
            $username = $korisnik->username;
            // dohvatanje licnog imena
            $licnoIme = $korisnik->licnoIme;
            if ($licnoIme == null)
                $licnoIme = "Nije uneto";
            // dohvatanje email
            $email = $korisnik->email;
            if ($email == null)
                $email = "Nije uneto";
            // dohvatanje kategorije korisnika
            $idKategorije = $korisnik->tipKorisnika_idTipKorisnika;
            $tipKorisnikaModel = new TipKorisnikaModel();
            $kategorija = $tipKorisnikaModel->find($idKategorije)->tip;

            echo ' <br> <br>          
            
        <div class="w3-row w3-center picture crvenaPozadina">
            <div class="w3-col s12"> 
            <div class="w3-center w3-text-white">';
            if ($korisnik->slika == null) {
                ?>
                <img src="<?php echo base_url(); ?>/photos/no_picture2.png" alt="" style="width:20%;">  
                <?php
            } else
                echo '<img src="data:image/jpeg;base64,' . base64_encode($korisnik->slika) . '">';

            echo 
                '</div>
                    </div>
                <div class="w3-row w3-center">
                    <div class="w3-col s12"> 
                    <br>
                        <div class="w3-center w3-text-white velika_slova"> ' . "$username" . '</div>
                    </div>
                </div>
                 
                <hr>
                <div class="w3-row w3-center">
                    <div class="w3-col s12"> 
                        <div class="slovaVelika">Lično ime: </div>
                        <div class="slovaMala">' . "$licnoIme" . '</div>  
                    </div>  
                </div>  
               <hr>

                <div class="w3-row" >
                    <div class="w3-col s12"> 
                        <div class="slovaVelika">Grad: </div>
                        <div class="slovaMala">' . "$nazivGrada" . '</div>
                    </div>
                </div>
                <hr>

                <div class="w3-row"">
                    <div class="slovaVelika">Email adresa: </div>
                    <div class="slovaMala">' . "$email" . '</div>
                </div>
                <hr>

                <div class="w3-row">
                    <div class="slovaVelika ">Pol: </div>
                    <div class="slovaMala ">' . "$pol" . '</div>
                </div>
                <br>
            </div>  <br> <br>   <br>
            ';          
            ?> 

    <?php
    require 'resources/footer.php';
    ?>

    </body>
    </html>
