        
        
<footer class="w3-container footer_stil">
        <div class="w3-left">
                <p style="color: white; font-weight: normal;">CardioGuardian - čuvar Vašeg zdravlja</p>
                <p style="color: white; font-weight: normal;">Projekat iz predmeta "Upravljanje softverskim projektima"</p>
        </div>
        <div class="w3-right">
                <img class="footer_slika w3-right" style="padding-right:25px; padding-top:8px" src="<?php echo base_url(); ?>/photos/cardioguardian.png" alt="">      
        </div>
</footer>