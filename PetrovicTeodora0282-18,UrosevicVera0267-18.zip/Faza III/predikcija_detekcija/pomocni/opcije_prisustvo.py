
# continuous vrednosti su brojevi
# 0 ili 1 su kao Muski/Zenski, Da/Ne ....
# to sam pogledala u .csv kako je sta

godina = 0
pol = ['Muski', 'Zenski']
bolUGrudimaVrednost = 0
krvniPritisakMirovanje = 0
holesterolVrednost = 0

fastingSecerUKrviVrednost = ['Ispod 120', 'Preko 120']
ecgMirovanjeVrednost = ['Dobar ECG', 'Los ECG']

maxOtkucajaSrcaVrednost = 0
bolPrilikomTreningaVrednost = ['Nema_bola', 'Ima_bola']

oldpeakVrednost = 0
STslopeVrednost = 0
