
# continuous vrednosti su brojevi
# 0 ili 1 su kao Muski/Zenski, Da/Ne ....
# to sam pogledala u .csv kako je sta

pol = ['Muski', 'Zenski']
godina = 0
pusac = ['Nepusac', 'Pusac']
cigNaDan = 0
BPMeds = ['Ne', 'Da']
prethodniUdar = ['Ne', 'Da']
hipertenzija = ['Ne', 'Da']
diabetes = ['Ne', 'Da']

totalHolesterol = 0
krvnipritisakG = 0
krvnipritisakD = 0
bmi = 0
brOtkSrca = 0
glukoza = 0
skola = ['Osnovna skola', 'Srednja skola', 'Visoko obrazovani', 'Master/Doktorske']
